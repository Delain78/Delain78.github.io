// based on steve's makerspace youtube tutorial

let bg;

function preload() {
  bg = loadImage("paper24.jpg");
}

function setup() {
	createCanvas(1080, 1080);
	colorMode(HSB, 360,120,100,255);
	background(210,0,0);
	strokeWeight(0.6);
	
	let rez1 = 0.003; // angle
	let rez2 = 0.005; // color
	let gap = 15;
	let len = 10; // = r
	let startVary = 25;
	
	strokeCap(SQUARE);
	
	for (let i = -20; i <width+20; i+= gap){
			for (let j = -20; j <height+20; j+= gap){
				let n2 = (noise(i * rez2, j * rez2)-0.2)*1.7;
				let h = floor (n2*5) * 72;
				stroke(h,90,90,150);
				x = i + random (-startVary, startVary);
				y = j + random (-startVary, startVary);;
				for (let k = 10; k > 0; k--){
					//strokeWeight(k*0.3);
					strokeWeight(random(6))
					n1= (noise (x * rez1,y* rez1)-0.2)*1.7;
					ang = n1 * TWO_PI // = angle
					newX = cos(ang)*len + x;
					newY = sin(ang)*len + y;
					line (x,y,newX,newY);
						x = newX;
						y = newY;
				}
		}
	}
	
	// paper texture
	filter(BLUR, 0.5);
	tint(0, 0, 100, 0.4);
  image(bg, 0, 0, bg.width, bg.height);

}


function keyPressed() {
  if (key === 's') {
    save('watercolorbackground.png'); 
  }
}
